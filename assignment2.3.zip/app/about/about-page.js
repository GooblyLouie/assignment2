//Encoura-Positigen, by Chris Cavalier

var gestures = require("tns-core-modules/ui/gestures");
var labelModule = require("tns-core-modules/ui/label");
const getCurrentPage = () => require("ui/frame").topmost();

function onHomeTap(args) {
    // Navigate to page called home-page”
    getCurrentPage.navigate("home/home-page");
}
exports.onHomeTap = onHomeTap;

function onEncourageTap(args) {
    // Navigate to page called “encourage-page”
    getCurrentPage.navigate("encouragement/encourage-page");
}
exports.onEncourageTap = onEncourageTap;

function onOptionsTap(args) {
    // Navigate to page called “options-page”
    getCurrentPage.navigate("options/options-page");
}
exports.onOptionsTap = onOptionsTap;

function onAboutTap(args) {
    // Navigate to page called about-page”
    getCurrentPage.navigate("about/about-page");
}
exports.onAboutTap = onAboutTap;

//Setting up a label to listen for gestures and navigate appropriately
var label = new labelModule.Label();
label.on(gestures.GestureTypes.swipe, function (args) {
    if (args.direction = "up") {
        onOptionsTap();
    }
});